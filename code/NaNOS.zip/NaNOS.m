% Phi: input data matrix, each row of Phi is a data point
% t  : response vector, continuous or binary; for binary response, t should
%      be in {1,-1}
% zi : initlization for approximation factor of Q(z)
% gzi: intilization for approximation factor of Q(gz)
% ind: the index set for each network
% M  : number of pathways
% opt: option set. opt.ntask: 1 -> regression ; ntask: 2-> classification
% ===============================Output=====================================
% mean_w: the estimated posterior for each node
% sel_index: selected nodes index
% sel_group: selected network index
% node_indicator: the posterior of node selection indicators
% network_indicator: the posterior of network selection indicators
function [mean_w, sel_index,sel_group, node_indicator, network_indicator] = NaNOS(Phi, t, L, ind, M, zi, gzi, opt)

if opt.ntask == 1 % For regression
    [n, dim] = size(Phi);
    %Phi = [Phi ones(n,1)];
    %dim = dim + 1;
    %x_test = [x_test  ones(size(x_test,1),1)];
    mean_w = zeros(dim,1);
    s1 = 1; s2 = 1e-3;
    %for every node within a network
    z = zi*ones(dim,1);
    %for every network
    gz = gzi*ones(M,1);
    g0 = ones(dim,1);
    h0 = ones(dim,1);
    gg0 = ones(M,1);
    gh0 = ones(M,1);
    g = g0;
    h = h0;
    gh = gg0;
    gg = gh0;
    c0 = 1e-12;
    d0 = 1e-12;
    tao = 1/std(t);
    niter = 0;
    while (niter<opt.max_iter)
        niter = niter + 1;
        A = diag(z)*1/s1  + diag(1-z)*1/s2;
        %%update for each pathway
        for i=1:M
            A(ind{1,i},ind{1,i}) = A(ind{1,i},ind{1,i}) +  gz(i)*1/s1*L{1,i} + (1-gz(i))*1/s2*L{1,i};
        end
        
        %%update Q(w) Sigma_w
        inv_var_w = A + tao*(Phi'*Phi);
        var_w =  inv_var_w\eye(size(inv_var_w));
        mean_w_old = mean_w;
        %%update Q(w) mu_w
        mean_w = inv_var_w\(tao*Phi' * t);
        %%update statistics of w
        wwmtp = var_w +  mean_w*mean_w';
        %%update Q(z)        
        for i=1:dim
            z(i) = 1/(1 + exp(psi(h(i))-psi(g(i)) + 0.5*log(s1/s2) + 0.5*wwmtp(i,i)*(1/s1-1/s2)));
        end
        %%update Q(sita) for each pathway
        g = g0 + z;
        h = h0 + 1 - z;     
        %%update Q(gz)
        for i=1:M
            %gz(i) = 1/(1+exp(psi(gh(i))-psi(gg(i))+ 0.5*length(ind{1,i})*log(s1/s2) + 0.5*trace(wwmtp(ind{1,i},ind{1,i}))*(1/s1-1/s2)));
            gz(i) = 1/(1+exp(psi(gh(i))-psi(gg(i))+ 0.5*length(ind{1,i})*log(s1/s2) + 0.5*trace(wwmtp(ind{1,i},ind{1,i})*L{1,i})*(1/s1-1/s2)));
        end
        %%update Q(gsita)
        gg = gg0 + gz;
        gh = gh0 + 1 - gz;
        %%update Q(tao)
        c = c0 + n/2;
        d = d0 + 0.5*(t'*t) - mean_w'*(Phi'*t) + 0.5*trace(Phi*wwmtp*Phi');
        tao = c/d;        
        diff_sum = sum(abs(mean_w_old - mean_w));
        index = find(z>0.5);
        fprintf('niter=%d, node_number=%d, diff_sum=%g\n',niter,length(index), diff_sum);
        if  ( sum(abs(mean_w_old- mean_w)) < opt.tol )
            break; % stop VB iteration
        end        
    end
    %the possible inconsistency of group selection & gene selection in
    %inference result, although never happen in practical usage
    for i=1:M
       	if sum(z(ind{1,i})>0.5) > 0 && gz(i) < 0.5
    		gz(i) = 1.0;
        end
        if sum(z(ind{1,i})>0.5) == 0 && gz(i) > 0.5
            gz(i) = 0.0;
        end        
    end
    node_indicator = z;
    network_indicator = gz;
    sel_index = index;
    sel_group = find(gz>0.5);
    pred_y = Phi * mean_w;
    fprintf('training error = %g\n', mean((t-pred_y).^2));
elseif opt.ntask ==2 %Binary classification
    [n, dim] = size(Phi);
    %Phi = [Phi ones(n,1)];
    %dim = dim + 1;
    %x_test = [x_test  ones(size(x_test,1),1)];
    mean_w = zeros(dim,1);
    var_w = eye(dim);
    wwmtp = var_w +  mean_w*mean_w';
    s1 = 1; s2 = 1e-3;
    %for every node within a network
    z = zi*ones(dim,1);
    %for every network
    gz = gzi*ones(M,1);
    g0 = ones(dim,1);
    h0 = ones(dim,1);
    gg0 = ones(M,1);
    gh0 = ones(M,1);
    g = g0;
    h = h0;
    gh = gg0;
    gg = gh0;    
    niter = 0;
    %varational parameter for logistic, epsilon
    lq = zeros(1,n);
    for i=1:n
    	lq(1,i) = sqrt( Phi(i,:)* wwmtp *Phi(i,:)');        
    end
    %lq = zeros(1,n);
    while (niter<opt.max_iter)
        niter = niter + 1;
        A = diag(z)*1/s1  + diag(1-z)*1/s2;
        %%update each pathway
        for i=1:M
            %A(ind{1,i},ind{1,i}) = A(ind{1,i},ind{1,i}) +  gz(i)*1/s1*eye(length(ind{1,i})) + (1-gz(i))*1/s2*eye(length(ind{1,i}));
            A(ind{1,i},ind{1,i}) = A(ind{1,i},ind{1,i}) +  gz(i)*1/s1*L{1,i} + (1-gz(i))*1/s2*L{1,i};
        end        
        %%update Q(w) Sigma_w
        lqbnd = (1 ./ (4*lq)) .* tanh(lq/2);
        B = 2 * diag( lqbnd );
        inv_var_w = A + Phi' * B * Phi;
        var_w =  inv_var_w\eye(size(inv_var_w));
        mean_w_old = mean_w;
        %%update Q(w) mu_w
        mean_w = inv_var_w\(0.5*Phi' * t);
        %%update statistics of w
        wwmtp = var_w +  mean_w*mean_w';
        %%update Q(z)
        for i=1:dim
            z(i) = 1/(1 + exp(psi(h(i))-psi(g(i)) + 0.5*log(s1/s2) + 0.5*wwmtp(i,i)*(1/s1-1/s2)));
        end
        %%update Q(sita) for each pathway
        g = g0 + z;
        h = h0 + 1 - z;     
        %%update Q(gz)
        for i=1:M
            gz(i) = 1/(1+exp(psi(gh(i))-psi(gg(i))+ 0.5*length(ind{1,i})*log(s1/s2) + 0.5*trace(wwmtp(ind{1,i},ind{1,i})*L{1,i})*(1/s1-1/s2)));
        end
        %%update varational paramter for logistic, epislon----lq
        lq = zeros(1,n);
        for i=1:n
            lq(1,i) = sqrt( Phi(i,:)* wwmtp *Phi(i,:)');
        end                
        %%update Q(sita) for whole
        gg = gg0 + gz;
        gh = gh0 + 1 - gz;
        
        diff_sum = sum(abs(mean_w_old - mean_w));
        index = find(z>0.5);
        fprintf('niter=%d, node_number=%d, diff_sum=%g\n',niter,length(index), diff_sum);
        if  ( sum(abs(mean_w_old- mean_w)) < opt.tol )
            break; % stop VB iteration
        end        
    end
    %the possible inconsistency of group selection & gene selection in
    %inference result, although never happen in practical usage
    for i=1:M
    	if sum(z(ind{1,i})>0.5) > 0 && gz(i) < 0.5
    		gz(i) = 1.0;
        end
        if sum(z(ind{1,i})>0.5) == 0 && gz(i) > 0.5
            gz(i) = 0.0;
        end        
    end
    node_indicator = z;
    network_indicator = gz;    
    sel_index = index;
    sel_group = find(gz>0.5);
    pred_y = Phi * mean_w;
    y1 = 1 + exp(-pred_y);
    y2 = 1./y1;
    pred_t = 2*(y2>0.5)-1;
    fprintf('training error = %g\n', sum(pred_t ~= t)/length(t));
end





