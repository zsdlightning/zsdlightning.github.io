clear all;
close all;

n = 200;
n_var = 2200;
M = 100;
X=randn(n_var,n);
for i=1:n
    trans=normrnd(0,1,1,100);
    for j=1:100
            start = (j-1)*22+1;
            X(start,i)= trans(j);
            X(start+1:start+20,i)=normrnd(trans(j)*0.7,sqrt(0.51),20,1);
    end
end
ind = cell(1,M);
for i=1:M
 	ind{1,i} = (i-1)*22 +(1:1:22);
end
adj = [0 ,ones(1,21);zeros(21,22)];
adj = adj + adj';
c = cell(1,M);
for k=1:M
 	c{1,k} = adj;
end
%laplacian matrix
L = cell(1,M);  
for k=1:M
   d = sum(c{1,k},2);
   e = d.^(-0.5);
   e = diag(e);
   L{1,k} = eye(length(ind{1,k}))-e*c{1,k}*e;
   %L{1,k} = L{1,k} + (1e-6)*eye(size(L{1,k}));
end


real_w = [5,5/sqrt(10)*ones(1,10),zeros(1,11),...
          -5, -5/sqrt(10)*ones(1,10),zeros(1,11),...
          3, 3/sqrt(10)*ones(1,10),zeros(1,11), ...
          -3, -3/sqrt(10)*ones(1,10),zeros(1,11), zeros(1,n_var-88)];
noise = sqrt( real_w*real_w'/4 );
real_y = real_w * X;
t = real_y + noise*randn(1,n);
n = length(t);

%split data
perm=randperm(n);
x_train = [X(:,perm(1:floor(end/4))) X(:,perm(floor(end/2)+1:floor(3*end/4)))]';
x_test = [X(:,perm(floor(end/4)+1:floor(end/2))) X(:,perm(floor(3*end/4)+1:end))]';
t_train = [t(:,perm(1:floor(end/4))) t(:,perm(floor(end/2)+1:floor(3*end/4)))]';
t_test =  [t(:,perm(floor(end/4)+1:floor(end/2))) t(:,perm(floor(3*end/4)+1:end))]';

fprintf('Simulation Starting....\n');
fprintf('2200 genes, within 100 pathways and each pathway contains 22 genes\n');
fprintf('4 pathways are related to the response\n');
fprintf('For each related pathway, 11 genes are related to the response.\n');

%Regression Case
opt.tol = 1e-3;
opt.max_iter = 50;
opt.ntask = 1;%1 for regession; 2 for classification
[mean_w, sel_index,sel_group, node_indicator, network_indicator] = NaNOS(x_train, t_train, L, ind, M, 0.9175, 0.92, opt);
fprintf('test error = %g\n', mean((t_test - x_test(:, sel_index)*mean_w(sel_index)).^2));
related_nodes = find(real_w~=0);
node_sensitivity = length(intersect(sel_index, related_nodes))/length(related_nodes);
node_specificity = 1 - length(setdiff(sel_index, related_nodes))/(n_var - length(related_nodes));
node_f1 = 2*node_sensitivity*node_specificity/(node_sensitivity + node_specificity);
net_sensitivity = sum(sel_group<=4)/4;
net_specificity = 1 - sum(sel_group>4)/(M-4);
net_f1 = 2*net_sensitivity*net_specificity/(net_sensitivity + net_specificity);
fprintf('Node selection:\n');
fprintf('Sensitivity = %g, Specificity = %g, F1 = %g\n', node_sensitivity, node_specificity, node_f1);
fprintf('Network selection:\n');
fprintf('Sensitivity = %g, Specificity = %g, F1 = %g\n', net_sensitivity, net_specificity, net_f1);

