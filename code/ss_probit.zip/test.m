
n = 200;
n_var = 440;
X3=randn(n_var,n);
%impose some structure information
for i=1:n
    trans=normrnd(0,1,1,40);
    for j=1:40
            start = (j-1)*11+1;
            X3(start,i)= trans(j);
            X3(start+1:start+10,i)=normrnd(trans(j)*0.7,sqrt(0.51),10,1);
    end
end

real_w = [5,5/sqrt(10)*ones(1,10),-5,-5/sqrt(10)*ones(1,10),3,3/sqrt(10)*ones(1,10),-3,-3/sqrt(10)*ones(1,10),zeros(1,n_var-44)];
real_y = real_w*X3;
t = real_y > 0;
t = 2*t-1;

p = randperm(n);
X = [X3(:,p(1:floor(end/4))) X3(:,p(floor(end/2)+1:floor(3*end/4)))];
X4 = [X3(:,p(floor(end/4)+1:floor(end/2))) X3(:,p(floor(3*end/4)+1:end))];
t_train = [t(:,p(1:floor(end/4))) t(:,p(floor(end/2)+1:floor(3*end/4)))];
t_test =  [t(:,p(floor(end/4)+1:floor(end/2))) t(:,p(floor(3*end/4)+1:end))];

t_train = t_train';
t_test = t_test';
x_train = X'; 
x_test = X4';


rho = 0.948175;
opt = [];
opt.max_iter = 1000;
opt.tol = 1e-4;
opt.verbose = 1;
[mean_w, sel_index,inv_var_w] = naive_ss_binary(x_train, t_train, rho, opt);

y = x_test(:,sel_index)*mean_w(sel_index);
t_result = 2*(y>0)-1;
prec = sum(t_result==t_test)/length(t_test);
fprintf(2,'prec = %g\n', prec);



