%Phi: n*p matrix, each row is a data point
%t should be in {-1,1}.
%notice that: init_z tends to be very important and the selection result is
%very sensitive to the configuration of init_z. Generally, it should be
%bigger than 0.9; Otherwise none of the variables can be selected.
function [mean_w, sel_index, inv_var_w]= naive_ss_binary(Phi, t, init_z, opt)
    if nargin < 4
      opt = [];
      opt.max_iter = 1000;
      opt.tol = 1e-5;
      opt.verbose = 1;
    end
    [n, dim] = size(Phi);
    var_w = eye(dim);
    mean_w = zeros(dim,1);
    wwmtp = var_w +  mean_w*mean_w';
    s1 = 1; s2 = 1e-6;
    y = t;
    t = (t<0).*ones(n,1) + (t>0).*ones(n,1)*2;
    z = init_z*ones(dim,1);
    g0 = ones(dim,1);
    h0 = ones(dim,1);
    g = g0;
    h = h0;
    niter = 0;
    b = [-inf;0;inf];
    while (niter<opt.max_iter)
        niter = niter + 1;
        A = diag(z)*1/s1  + diag(1-z)*1/s2;        
        %%update Q(w) Sigma_w
        inv_var_w = A + Phi'*Phi;
        var_w =  inv_var_w\eye(size(inv_var_w));
        mean_w_old = mean_w;
        %%update Q(w) mu_w
        mean_w = inv_var_w\(Phi' * y);
        %%update statistics of w
        wwmtp = var_w +  mean_w*mean_w';
        %%update Q(z)        
        for i=1:dim
            z(i) = 1/(1 + exp(psi(h(i))-psi(g(i)) + 0.5*log(s1/s2) + 0.5*wwmtp(i,i)*(1/s1-1/s2)));
        end
        %%update Q(sita)
        g = g0 + z;
        h = h0 + 1 - z;
        diff_sum = sum(abs(mean_w_old - mean_w));
        if opt.verbose
            fprintf(2,'niter= %d, feature no. = %d, diff_sum=%f\n',niter, length(find(z>0.5)), diff_sum);        
        end
        if  (diff_sum < opt.tol )
            break; % stop VB iteration
        end
        %%update Q(y)--probit regression
        my = Phi*mean_w;
        y = my + (normpdf(b(t),my,ones(n,1))-normpdf(b(t+1),my,ones(n,1)))./(normcdf(b(t+1)-my) - normcdf(b(t)-my));
    end
    sel_index = find(z>0.5);  
end





